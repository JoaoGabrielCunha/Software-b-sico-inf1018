#include <stdio.h>
typedef int (*funcp) ();
funcp compilaLinB (FILE *f, unsigned char codigo[]);